def test():
    return 5
